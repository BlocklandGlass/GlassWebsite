messageBoxOk("Restart", "You must now restart Blockland", "quit();");
